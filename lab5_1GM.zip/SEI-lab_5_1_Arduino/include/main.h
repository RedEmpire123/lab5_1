#ifndef MAIN_H
#define MAIN_H

#include <Arduino.h>
#include <my_tasks.h>
#include "config.h"

void setup();
void loop();

#endif // MAIN_H
